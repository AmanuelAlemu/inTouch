package com.example.intouch;

import java.util.ArrayList;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

public class UserProfileActivity extends ActionBarActivity 
{
	private LinearLayout mLayout;
	private ContactsDbAdapter mDbHelper;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user_profile);
		mDbHelper = new ContactsDbAdapter(this);
		mDbHelper.open();
		ArrayList<String> groupNames = mDbHelper.getGroupNames();
		
		mLayout = (LinearLayout)findViewById(R.id.group_list);
		
		for (String groupName : groupNames)
		{
			TextView tv = (TextView)LayoutInflater.from(UserProfileActivity.this).inflate(R.layout.contacts_list_item2, mLayout, false);
			tv.setText(groupName);
			tv.setTextSize(25);
			
			mLayout.addView(tv);
			
			ArrayList<String> contactNames = mDbHelper.getContactNamesFromGroup(groupName);
			
			LinearLayout mLayout2 = (LinearLayout)LayoutInflater.from(UserProfileActivity.this).inflate(R.layout.contacts_list_view, mLayout, false);
			for (String contactName : contactNames)
			{
				TextView tv2 = (TextView)LayoutInflater.from(UserProfileActivity.this).inflate(R.layout.contacts_list_item2, mLayout2, false);
				tv2.setText(contactName);
				tv2.setTextSize(35);
				mLayout2.addView(tv2);
			}
			mLayout.addView(mLayout2);
			tv.setOnClickListener(new MyClickListener(mLayout2));
		}	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.user_profile, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) 
		{
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public class MyClickListener implements OnClickListener
	{
		private final LinearLayout mLayout2;
		
		public MyClickListener(LinearLayout mLayout2)
		{
			this.mLayout2 = mLayout2;
		}
		
		@Override
		public void onClick(View v)
		{
			if (v.isSelected())
				mLayout2.setVisibility(View.GONE);
			
			else
				mLayout2.setVisibility(View.VISIBLE);
			
			v.setSelected(!v.isSelected());
		}
	}
}