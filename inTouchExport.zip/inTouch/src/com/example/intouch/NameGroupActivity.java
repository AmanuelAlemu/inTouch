package com.example.intouch;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

/**
 * Simple screen to name a group.
 */
public class NameGroupActivity extends ActionBarActivity 
{	
	/* (non-Javadoc)
	 * @see android.support.v7.app.ActionBarActivity#onCreate(android.os.Bundle)
	 * 
	 * Given by eclipse, modified. When this activity is created, it will receive 
	 * the intent from the activity that started it, then simply wait for select
	 * contacts to be pressed
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_name_group);
		getIntent();
		Button selectContacts = (Button)findViewById(R.id.selectContacts);
		selectContacts.setOnClickListener(selectContactsHandler);
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onCreateOptionsMenu(android.view.Menu)
	 * 
	 * Given by Eclipse, not modified
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu)  
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.name_group, menu);
		return true;
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
	 * 
	 * Given by Eclipse, not modified
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * Listener for the select Contacts button. When clicked, will start
	 * the SelectContactsForGroup Activity
	 */
	private OnClickListener selectContactsHandler = new OnClickListener()
	{
		public void onClick(View v)
		{
			EditText textField = (EditText)findViewById(R.id.nameGroup);
			String groupName = textField.getText().toString();
			Intent intent = new Intent(NameGroupActivity.this, SelectContactsForGroup.class);
			intent.putExtra("groupNameField", groupName);
			startActivity(intent);
		}
	};
}