package com.example.intouch;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ContactsDbAdapter {

	private DatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;
	
	private final Context mContext;
	
	// Logcat
	// private static final String LOG = "ContactsDbAdapter";
	
	// Database Name
	private static final String DATABASE_NAME = "contactsManager";
	
	// Database Version
	private static final int DATABASE_VERSION = 1;
	
	// Table Names
	private static final String TABLE_CONTACTS = "contacts";
	private static final String TABLE_GROUPS = "groups";
	private static final String TABLE_MEMBERSHIPS = "memberships";
	
	// Common column Names
	private static final String KEY_ID = "id";
	
	// CONTACTS Table - column names
	private static final String CONTACT_NAME = "contact_name";
	private static final String PHONE_NUMBER = "phone_number";
	private static final String EMAIL = "email";
	
	// GROUPS Table - Column Names
	private static final String GROUP_NAME = "group_name";
	
	// MEMBERSHIP Table - Column Names
	private static final String CONTACT_ID = "contact_id";
	private static final String GROUP_ID = "group_id";
	
	private static final String CREATE_CONTACTS_TABLE = "CREATE TABLE "
			+ TABLE_CONTACTS + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
			+ CONTACT_NAME + " TEXT," + PHONE_NUMBER + " TEXT," + EMAIL + 
			" TEXT" + ")";
	
	private static final String CREATE_GROUPS_TABLE = "CREATE TABLE "
			+ TABLE_GROUPS + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
			+ GROUP_NAME + " TEXT" + ")";
	
	private static final String CREATE_MEMBERSHIP_TABLE = "CREATE TABLE "
			+ TABLE_MEMBERSHIPS + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
			+ CONTACT_ID + " INTEGER," + GROUP_ID + " INTEGER," + GROUP_NAME + " TEXT," 
			+ " FOREIGN KEY ("+CONTACT_ID+") REFERENCES "+TABLE_CONTACTS+"("+KEY_ID+"),"
			+ " FOREIGN KEY ("+GROUP_ID+") REFERENCES "+TABLE_GROUPS+"("+KEY_ID+")"
			+ " FOREIGN KEY ("+GROUP_NAME+") REFERENCES "+TABLE_GROUPS+"("+GROUP_NAME+"))";
	
	private static class DatabaseHelper extends SQLiteOpenHelper 
	{
		DatabaseHelper(Context context)
		{
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
		
		@Override
		public void onCreate(SQLiteDatabase db)
		{
			db.execSQL(CREATE_CONTACTS_TABLE);
			db.execSQL(CREATE_GROUPS_TABLE);
			db.execSQL(CREATE_MEMBERSHIP_TABLE);
		}
		
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
		{
			db.execSQL("DROP TABLE IF EXISTS" + " TABLE_CONTACTS");
			db.execSQL("DROP TABLE IF EXISTS" + " TABLE_GROUPS");
			db.execSQL("DROP TABLE IF EXISTS" + " TABLE_MEMBERSHIPS");
			onCreate(db);
		}	
	}
	
	public ContactsDbAdapter(Context context)
	{
		this.mContext = context;
	}
	
	public ContactsDbAdapter open()
	{
		mDbHelper = new DatabaseHelper(mContext);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}
	
	public void close()
	{
		mDbHelper.close();
	}
	
	public long createContact(Contact contact)
	{
		ContentValues values = new ContentValues();
		values.put(CONTACT_NAME, contact.getContactName());
		values.put(PHONE_NUMBER, contact.getContactNumber());
		values.put(EMAIL, contact.getContactEmail());
		
		return mDb.insert(TABLE_CONTACTS, null, values);
	}
	
	public long createGroup(Group group)
	{
		ContentValues values = new ContentValues();
		values.put(GROUP_NAME, group.getName());
		long groupId = mDb.insert(TABLE_GROUPS, null, values);
		
		ArrayList<Contact> contacts = group.getContacts();
		for (Contact contact : contacts)
			createMembership(group, groupId, contact);
		
		
		return groupId;
	}
	
	public long createMembership(Group group, long groupId, Contact contact)
	{
		ContentValues values = new ContentValues();
		String[] projection = { KEY_ID };
		String selection = "contact_name=?";
		String[] args = {contact.getContactName()};
		
		Cursor person = mDb.query(TABLE_CONTACTS, projection, selection, args, null, null, null);
		if (person.moveToNext())
		{
			String contact_id = person.getString(0);
			values.put(CONTACT_ID, contact_id);
			values.put(GROUP_ID, groupId);
		}
		person.close();
		values.put(GROUP_NAME, group.getName());
		return mDb.insert(TABLE_MEMBERSHIPS, null, values);
	}
	
	public ArrayList<Contact> getAllContacts()
	{
		String[] projection = {CONTACT_NAME};
		ArrayList<Contact> allContacts = new ArrayList<Contact>();
		Cursor cursor = mDb.query(TABLE_CONTACTS, projection, null, null, null, null, "CONTACT_NAME");
		
		while (cursor.moveToNext())
		{
			Contact contact = new Contact();
			contact.setContactName(cursor.getString(cursor.getColumnIndex(CONTACT_NAME)));
			allContacts.add(contact);
		}
		cursor.close();
		return allContacts;
	}
	
	public ArrayList<String> getGroupNames()
	{
		ArrayList<String> groupNames = new ArrayList<String>();
		String[] projection = {GROUP_NAME};
		
		Cursor cursor = mDb.query(TABLE_GROUPS, projection, null, null, null, null, GROUP_NAME);
		
		while (cursor.moveToNext())
		{
			String name = cursor.getString(0);
			groupNames.add(name);
		}
		
		return groupNames;
	}
	
	public ArrayList<String> getContactNamesFromGroup(String groupName)
	{
		ArrayList<String> contactNames = new ArrayList<String>();
		String[] projection = {CONTACT_ID};
		String selection = "group_name=?";
		Cursor group = mDb.query(TABLE_MEMBERSHIPS, projection, selection, new String[] {groupName}, null, null, null);
		
		while (group.moveToNext())
		{
			String[] projection2 = {CONTACT_NAME};
			String selection2 = "id=?";
			String[] args = {group.getString(0)};
			Cursor cursor = mDb.query(TABLE_CONTACTS, projection2, selection2, args, null, null, null);
			while (cursor.moveToNext())
			{
				String contactName = cursor.getString(0);
				contactNames.add(contactName);
			}
		}
		return contactNames;
	}
}