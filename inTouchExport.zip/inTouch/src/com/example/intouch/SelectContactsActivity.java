package com.example.intouch;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;


/**
 * Workhorse of the app, reads all contacts from system and displays them
 * 
 * Instance Variables:
 * 
 * contacts 			- list of all contacts
 * linearLayout 		- the layout of the activity
 * nextButton 			- button that appears once contacts are selected
 * numContactsSelected 	- keeps track of how many contacts the user has selected
 * mDbHelper 			- helper variable to assist with database reading/modification
 *
 */
public class SelectContactsActivity extends ActionBarActivity 
{
	
	private ArrayList<Contact> contacts = new ArrayList<Contact>();
	private LinearLayout linearLayout;
	private TextView nextButton;
	private int numContactsSelected = 0;
	private ContactsDbAdapter mDbHelper;
	
    /* (non-Javadoc)
     * @see android.support.v7.app.ActionBarActivity#onCreate(android.os.Bundle)
     * 
     * Given by Eclipse, modified. When the activity is created, a new database
     * is created OR the existing one is opened. Calls both searchContacts and
     * displayContacts to process and display system contacts
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_contacts);
	    mDbHelper = new ContactsDbAdapter(this);
	    mDbHelper.open();
        linearLayout = (LinearLayout)findViewById(R.id.info);
        nextButton = (TextView)findViewById(R.id.next_button);
        nextButton.setOnClickListener(nextHandler);
        ArrayList<Contact> tempContactList = searchContacts();
        displayContacts(tempContactList);
    }
    
    /**
     * Click listener for the next button. When the next button is clicked,
     * this loops through contacts that the user has selected and adds each
     * one to the database
     */
    public OnClickListener nextHandler = new OnClickListener()
    {
    	public void onClick(View v)
    	{
    		for (Contact contact : contacts)
    			mDbHelper.createContact(contact);
    		
    		Intent intent = new Intent(SelectContactsActivity.this, CreateGroupActivity.class);
    		startActivity(intent);
    	}	
    };
    
    /**
     * Custom listener for each contact. When a contact is selected,
     * the plus on the right turns into a checkmark and the contact
     * is added to the big contacts list. If clicked again, it resets
     * to a plus and removes the contact from the list
     *
     */
    public class MyClickListener implements OnClickListener
    {
    	private Contact contact;
    	
    	public MyClickListener(Contact contact)
    	{
    		this.contact = contact;
    	}
    	
    	public void onClick(View v)
    	{
    		if (v.isSelected() == true)	    // This is the logic to keep track of whether to display the next button or not.
			   {   
				   numContactsSelected--;	    // It works the opposite way of what you'd expect. I guess isSelected() starts off as true
			   	   contacts.remove(contact);	// then changes to false
			   }   
			   else
			   {
				   numContactsSelected++;
				   contacts.add(contact);
			   }
			   v.setSelected(!v.isSelected());
			   
			   if (numContactsSelected == 0)
				   nextButton.setVisibility(View.GONE);
			   else
				   nextButton.setVisibility(View.VISIBLE);
    	}
    }
    
    /* (non-Javadoc)
     * @see android.app.Activity#onCreateOptionsMenu(android.view.Menu)
     * 
     * Given by Eclipse, not modified
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) 
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.select_contacts, menu);
        return true;
    }
    
    /* (non-Javadoc)
     * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
     * 
     * Given by Eclipse, not modified
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) 
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    /**
     * @return - returns a list of all contacts that have phone numbers in the user's phone
     * 
     * This is where the work is done. This function searches the system contacts for contacts that
     * have a phone number (this can and should probably change later to include contacts with emails
     * but no phone later).
     */
    public ArrayList<Contact> searchContacts() 
    {
    	// Objects to set up search
    	LinkedHashMap<String, Contact> contactList = new LinkedHashMap<String, Contact>();	
    	ArrayList<Contact> tempContactList = new ArrayList<Contact>();
	    
    	// The columns of databases that we want to search
    	String[] projection = 
	    {
	    		ContactsContract.Data.CONTACT_ID, 
	    		ContactsContract.Data.MIMETYPE,
	    		
	    		// Apparently this only works on API 11 and above, would be nice to find a solution that works on API 8
	    		ContactsContract.CommonDataKinds.Email.ADDRESS, 
	    		ContactsContract.Contacts.DISPLAY_NAME,
	    		ContactsContract.CommonDataKinds.Phone.NUMBER,
	    		ContactsContract.Contacts.HAS_PHONE_NUMBER
	    };
	    String sortOrder = "DISPLAY_NAME";
	    
	    // Perform search on defined columns, return a cursor to that list
	    Cursor people = getContentResolver().query(ContactsContract.Data.CONTENT_URI, projection, null, null, sortOrder);
	    
	    // 6 columns that correspond to the query results. These are numbered
	    // 0-5 and correspond with the projection columns above
	    final int mimeTypeIdx = people.getColumnIndex(ContactsContract.Data.MIMETYPE);
	    final int idIdx = people.getColumnIndex(ContactsContract.Data.CONTACT_ID);
	    final int nameIdx = people.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
	    
	    // Same thing here, once the above API warning is resolved, this won't be an issue
	    final int emailIdx = people.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS);
	    final int numberIdx = people.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
	    final int hasPhoneIdx = people.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER);

	    // Move through the cursor and process each contact, add them to contact list
	    while(people.moveToNext()) 
	    {
		   int hasPhone = people.getInt(hasPhoneIdx); 							  
		   if (hasPhone == 1)
		   {
			   final Contact contact;
			   
			   String id = people.getString(idIdx);
			   String mimeType = people.getString(mimeTypeIdx);
			   String name = people.getString(nameIdx);
			   String number = people.getString(numberIdx);
			   String email = people.getString(emailIdx);
			   
			   if (contactList.containsKey(id))
				   contact = contactList.get(id);
			   
			   else
			   {
				   contact = new Contact();
				   contactList.put(id, contact);
			   }
		   
			   if (mimeType.equals(ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE))
			   {
				   contact.setContactName(name);
			   }
			   if (mimeType.equals(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE))
			   {
				   contact.setContactNumber(number);
			   }
			   if (mimeType.equals(ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE))
			   {
				   contact.setContactEmail(email);
			   }  
		   }
	    }
	    people.close();
	    
	    tempContactList.addAll(contactList.values());
	    
	    
	    // Check for null contact objects and remove them.
	    for (Contact _contact : contacts)
	    {
	    	if (_contact.getContactName() == null &&
	    		_contact.getContactNumber() == null &&
	    		_contact.getContactEmail() == null)
	    	{
	    		tempContactList.remove(_contact);
	    	}
	    	
	    }
	    return tempContactList;
	}
		   
    /**
     * @param contactList - The big list of all contacts in user's phone that have phone numbers
     * 
     * This function displays the list of contacts to the screen and sets a 
     * click listener for each one so the user can select/deselect them.
     */
    public void displayContacts(ArrayList<Contact> contactList)
    {
    	for (Contact contact : contactList)
    	{
	    	TextView tv = (TextView)LayoutInflater.from(SelectContactsActivity.this).inflate(R.layout.contacts_list_item, linearLayout, false);
			tv.setText(contact.getContactName());
			tv.setTextSize(20); // Size of letters
			tv.setPadding(0,35,0,35); // Padding between name and border
			tv.setOnClickListener(new MyClickListener(contact));
			linearLayout.addView(tv);
    	}
    }
}