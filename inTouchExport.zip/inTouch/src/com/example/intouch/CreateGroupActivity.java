package com.example.intouch;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class CreateGroupActivity extends ActionBarActivity 
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_create_group);
		getIntent();
		Button createGroupButton = (Button)findViewById(R.id.create_group);
		createGroupButton.setOnClickListener(createGroupHandler);
		Button doneButton = (Button)findViewById(R.id.skip_button);
		doneButton.setOnClickListener(doneHandler);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.create_group, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	private OnClickListener createGroupHandler = new OnClickListener()
	{
		public void onClick(View v)
		{
			Intent intent = new Intent(CreateGroupActivity.this, NameGroupActivity.class);
			startActivity(intent);
		}
	};
	
	private OnClickListener doneHandler = new OnClickListener()
	{
		public void onClick(View v)
		{
			Intent intent = new Intent(CreateGroupActivity.this, UserProfileActivity.class);
			startActivity(intent);
		}
	};
}