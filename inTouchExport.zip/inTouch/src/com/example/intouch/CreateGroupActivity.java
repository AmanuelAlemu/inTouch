package com.example.intouch;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/**
 * Simple screen to create a new Group. Gives the user 2 buttons,
 * either create a group or click Done to skip
 *
 */
public class CreateGroupActivity extends ActionBarActivity 
{
	/* (non-Javadoc)
	 * @see android.support.v7.app.ActionBarActivity#onCreate(android.os.Bundle)
	 * 
	 * Given by eclipse, modified. Receive intent from previous activity and show
	 * 2 buttons when the screen is created
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_create_group);
		getIntent();
		Button createGroupButton = (Button)findViewById(R.id.create_group);
		createGroupButton.setOnClickListener(createGroupHandler);
		Button doneButton = (Button)findViewById(R.id.skip_button);
		doneButton.setOnClickListener(doneHandler);
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onCreateOptionsMenu(android.view.Menu)
	 * 
	 * Given by eclipse, not modified
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.create_group, menu);
		return true;
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
	 * Given by eclipse, not modified
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	/**
	 * Click listener for the create group button. If clicked,
	 * takes user to CreateGroupActivity
	 * 
	 */
	private OnClickListener createGroupHandler = new OnClickListener()
	{
		public void onClick(View v)
		{
			Intent intent = new Intent(CreateGroupActivity.this, NameGroupActivity.class);
			startActivity(intent);
		}
	};
	
	
	/**
	 * If user does not want to create group and clicks done, this listener
	 * will respond to pressing done and take user to home screen
	 */
	private OnClickListener doneHandler = new OnClickListener()
	{
		public void onClick(View v)
		{
			Intent intent = new Intent(CreateGroupActivity.this, MainActivity.class);
			startActivity(intent);
		}
	};
}