
package com.example.intouch;
import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * This is the main page of the app. The app opens to this
 * screen if it is not the first time it is being run.
 * 
 * Instance variables:
 * 
 * mPrefs 				- used to save user preferences within the app
 * contactsSelectedPref - ends up as a boolean used to decide which screen 
 * 						  to open when the app runs
 * showExitDialogPref 	- ends up as a boolean used to decide whether to 
 * 						  immediately exit the app upon pressing back on the home screen
 * mLayout 				- the layout of the page
 * mDbHelper 			- helper variable that assists with database creation/modification
 * 
 */

public class MainActivity extends ActionBarActivity 
{
	private SharedPreferences mPrefs;
	final String contactsSelectedPref = "contactsSelected";
	final String showExitDialogPref = "showExitDialog";
	private LinearLayout mLayout;
	private ContactsDbAdapter mDbHelper;
	
	/* (non-Javadoc)
	 * @see android.support.v7.app.ActionBarActivity#onCreate(android.os.Bundle)
	 * 
	 * onCreate decides what happens when this activity is created.
	 * Given by eclipse, modified
	 * 
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// Decide whether to launch this activity or start the SelectContactsActivity
		// This activity will launch by default unless it's the very first time running the app
		mPrefs = PreferenceManager.getDefaultSharedPreferences(this); 
        Boolean contactsSelected = mPrefs.getBoolean(contactsSelectedPref, false);
		
        if (!contactsSelected)
        {
        	Intent intent = new Intent(MainActivity.this, SelectContactsActivity.class);
        	startActivity(intent);
			SharedPreferences.Editor editor = mPrefs.edit();
	        editor.putBoolean(contactsSelectedPref, true);
	        editor.commit();
        }
        
        // Read group information from the database to display on the home screen
		mDbHelper = new ContactsDbAdapter(this);
		mDbHelper.open();
		ArrayList<String> groupNames = mDbHelper.getGroupNames();
		
		mLayout = (LinearLayout)findViewById(R.id.group_list);
		
		for (String groupName : groupNames)
		{
			TextView tv = (TextView)LayoutInflater.from(MainActivity.this).inflate(R.layout.contacts_list_item2, mLayout, false);
			tv.setText(groupName);
			tv.setTextSize(25);
			
			mLayout.addView(tv);
			
			ArrayList<String> contactNames = mDbHelper.getContactNamesFromGroup(groupName);
			
			LinearLayout mLayout2 = (LinearLayout)LayoutInflater.from(MainActivity.this).inflate(R.layout.contacts_list_view, mLayout, false);
			for (String contactName : contactNames)
			{
				TextView tv2 = (TextView)LayoutInflater.from(MainActivity.this).inflate(R.layout.contacts_list_item2, mLayout2, false);
				tv2.setText(contactName);
				tv2.setTextSize(35);
				mLayout2.addView(tv2);
			}
			mLayout.addView(mLayout2);
			tv.setOnClickListener(new MyClickListener(mLayout2));
		}	
	}

	
	/* (non-Javadoc)
	 * @see android.app.Activity#onCreateOptionsMenu(android.view.Menu)
	 * 
	 * Given by eclipse, not modified
	 * 
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
	 * 
	 * Given by eclipse, modified
	 * Uses a switch statement to decide which button was pressed and then
	 * act accordingly. If the new group button was selected, it starts the
	 * CreateGroupActivity
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		switch (item.getItemId())
		{
			case R.id.action_settings:
				return true;
			case R.id.create_group_icon:
				Intent intent = new Intent(MainActivity.this, CreateGroupActivity.class);
				startActivity(intent);
			default:
				return super.onOptionsItemSelected(item);
		}
	}
	
	
	
	/**
	 * Custom listener class. Reacts to clicks on group names and toggles 
	 * showing the contacts for that group
	 *
	 */
	public class MyClickListener implements OnClickListener
	{
		private final LinearLayout mLayout2;
		
		public MyClickListener(LinearLayout mLayout2)
		{
			this.mLayout2 = mLayout2;
		}
		
		@Override
		public void onClick(View v)
		{
			if (v.isSelected())
				mLayout2.setVisibility(View.GONE);
			
			else
				mLayout2.setVisibility(View.VISIBLE);
			
			v.setSelected(!v.isSelected());
		}
	}
	
	/* (non-Javadoc)
	 * @see android.support.v7.app.ActionBarActivity#onBackPressed()
	 * 
	 * Define back button behavior on for this activity (home screen)
	 * When back button is pressed, a dialog pops up asking the user if 
	 * they're sure they want to leave. The user can select whether to show
	 * the dialog the next time or not.
	 */
	@Override
	public void onBackPressed()
	{
		// Get user preference for showing dialog and evaluate it
		mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
		Boolean showExitDialog = mPrefs.getBoolean(showExitDialogPref, true);
		
		// If they previously chose not to see the dialog, just close
		if(!showExitDialog)
			finish();
		
		// Otherwise, create the dialog and show it
		else
		{
			View checkBoxView = View.inflate(this, R.layout.checkbox, null);
			final CheckBox exitCheckBox = (CheckBox)checkBoxView.findViewById(R.id.exit_checkbox);
			exitCheckBox.setText("Do not show this message again.");
			
			AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
			dialogBuilder.setMessage("This will exit the app. Are you sure?");
			dialogBuilder.setCancelable(true);
			dialogBuilder.setView(checkBoxView);
			
			dialogBuilder.setPositiveButton("Exit", new DialogInterface.OnClickListener()
			{
				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					// If the user has checked the box and then clicks ok, save the preference
					if (exitCheckBox.isChecked())
					{
						SharedPreferences.Editor editor = mPrefs.edit();
						editor.putBoolean(showExitDialogPref, false);
						editor.commit();
					}
					finish();
				}
			});
			
			dialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
			{
				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					dialog.cancel();
				}
			});
			
			AlertDialog exitDialog = dialogBuilder.create();
			exitDialog.show();
		}
	}
}
